<?php
    /**
     * Constants
     */
?>