<?php
    define('PATH', './php/');
?>