<?php
    /*----------------------------------------------------------*/
    /**
     * File Conversion Class. 
     * - Contains common properties and methods for file conversions.
     */
    /*----------------------------------------------------------*/
    class FileConverter {
        /*----------------------------------------------------------*/
        /**
         * Construct for File Converter Class
         */
        /*----------------------------------------------------------*/
        public function __construct(){
            
        }
    }
?>