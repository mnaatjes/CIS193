<?php
    /**
     * Constant Definitions for Error Handling
     */
    define('CONVERT_ERROR_SKIP', 0);
    define('CONVERT_ERROR_STOP', 1);
    define('CONVERT_ERROR_LOG', 2);
?>