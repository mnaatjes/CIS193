<?php
    /**
     * @var array $mime_types - Mime types which resolve to other mime types
     */
    define('MIME_TYPES', [

    ]);
?>