<?php
    /**
     *  HTML Components
     */
    require_once 'component-obj.php';
    /**
     * HTML Element Components
     */
    require_once 'component-heading.php';
    require_once 'component-button.php';
    require_once 'component-list.php';
    require_once 'component-table.php';
    /**
     * Form Compoent and Form Elements
     */
    require_once 'component-form/component-form.php';
    require_once 'component-form/component-form-element.php';
    require_once 'component-form/element-label.php';
    require_once 'component-form/element-select.php';
    require_once 'component-form/element-button.php';
    /*
    require_once 'component-form/element-text.php';
    */
?>